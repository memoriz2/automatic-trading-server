import crypto from 'crypto';
import jwt from 'jsonwebtoken';

export interface UpbitTicker {
  market: string;
  trade_price: number;
  timestamp: number;
}

export interface UpbitOrderbook {
  market: string;
  orderbook_units: Array<{
    ask_price: number;
    bid_price: number;
    ask_size: number;
    bid_size: number;
  }>;
}

export class UpbitService {
  private baseUrl = 'https://api.upbit.com';
  private accessKey: string;
  private secretKey: string;

  constructor(accessKey?: string, secretKey?: string) {
    this.accessKey = accessKey || process.env.UPBIT_ACCESS_KEY || '';
    this.secretKey = secretKey || process.env.UPBIT_SECRET_KEY || '';
  }

  private generateAuthToken(query?: string): string {
    if (!this.accessKey || !this.secretKey) {
      throw new Error('Upbit API keys not configured');
    }

    const payload: any = {
      access_key: this.accessKey,
      nonce: Date.now().toString(),
    };

    if (query) {
      payload.query_hash = crypto.createHash('sha512').update(query, 'utf-8').digest('hex');
      payload.query_hash_alg = 'SHA512';
    }

    return jwt.sign(payload, this.secretKey);
  }

  async getTicker(markets: string[]): Promise<UpbitTicker[]> {
    try {
      const marketString = markets.join(',');
      const response = await fetch(`${this.baseUrl}/v1/ticker?markets=${marketString}`);
      
      if (!response.ok) {
        throw new Error(`Upbit API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Upbit getTicker error:', error);
      throw error;
    }
  }

  async getOrderbook(markets: string[]): Promise<UpbitOrderbook[]> {
    try {
      const marketString = markets.join(',');
      const response = await fetch(`${this.baseUrl}/v1/orderbook?markets=${marketString}`);
      
      if (!response.ok) {
        throw new Error(`Upbit API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Upbit getOrderbook error:', error);
      throw error;
    }
  }

  // 중복된 getAccounts 메서드 제거 - 아래쪽에 올바른 메서드가 있음

  async getKRWBalance(): Promise<number> {
    try {
      const accounts = await this.getAccounts();
      const krwAccount = accounts.find(account => account.currency === 'KRW');
      return krwAccount ? parseFloat(krwAccount.balance) : 0;
    } catch (error) {
      console.error('Upbit getKRWBalance error:', error);
      return 0;
    }
  }

  async getMarkets(): Promise<Array<{ market: string; korean_name: string; english_name: string }>> {
    try {
      const response = await fetch(`${this.baseUrl}/v1/market/all`);
      
      if (!response.ok) {
        throw new Error(`Upbit API error: ${response.status}`);
      }

      const markets = await response.json();
      return markets.filter((market: any) => market.market.startsWith('KRW-'));
    } catch (error) {
      console.error('Upbit getMarkets error:', error);
      throw error;
    }
  }

  async getAccounts(): Promise<any[]> {
    try {
      const authToken = this.generateAuthToken();
      
      const response = await fetch(`${this.baseUrl}/v1/accounts`, {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Upbit API response:', response.status, errorText);
        throw new Error(`Upbit API error: ${response.status} - ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Upbit getAccounts error:', error);
      throw error;
    }
  }

  private async sendRequest(endpoint: string, method: 'GET' | 'POST' | 'DELETE', params: any = {}): Promise<any> {
    const url = `${this.baseUrl}/v1/${endpoint}`;
    const nonNilParams = Object.fromEntries(Object.entries(params).filter(([, v]) => v != null));
    
    // Convert all param values to strings for URLSearchParams
    const stringParams: Record<string, string> = {};
    for (const key in nonNilParams) {
      stringParams[key] = String(nonNilParams[key]);
    }
    
    const queryString = new URLSearchParams(stringParams).toString();
    const authToken = this.generateAuthToken(queryString || undefined);

    const options: RequestInit = {
      method,
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      },
    };

    let fullUrl = url;
    if (method === 'GET' || method === 'DELETE') {
      if (queryString) fullUrl += `?${queryString}`;
    } else if (method === 'POST') {
      options.body = JSON.stringify(nonNilParams);
    }

    const response = await fetch(fullUrl, options);

    if (!response.ok) {
      const errorBody = await response.text();
      throw new Error(`Upbit API error (${response.status}): ${errorBody}`);
    }

    return response.json();
  }

  // 지정가 매수
  async placeBuyOrder(market: string, price: number, orderType: 'limit' | 'price' = 'price'): Promise<any> {
    try {
      const params: any = {
        market,
        side: 'bid',
        ord_type: orderType,
      };
      if (orderType === 'limit') {
        params.price = price.toString();
      } else {
        params.price = price.toString(); // 시장가 매수 시 총액
      }
      return this.sendRequest('orders', 'POST', params);
    } catch (error) {
      console.error('Upbit placeBuyOrder error:', error);
      throw new Error(`주문 조회 실패: ${(error as Error).message}`);
    }
  }

  async placeSellOrder(market: string, volume: number): Promise<any> {
    try {
      const params = {
        market,
        side: 'ask',
        volume: volume.toString(),
        ord_type: 'limit',
      };
      return this.sendRequest('orders', 'POST', params);
    } catch (error) {
      console.error('Upbit placeSellOrder error:', error);
      throw error;
    }
  }

  async cancelOrder(uuid: string): Promise<any> {
    const params = { uuid };
    return this.sendRequest('order', 'DELETE', params);
  }
}
